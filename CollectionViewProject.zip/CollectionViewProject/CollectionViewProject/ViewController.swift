//
//  ViewController.swift
//  CollectionViewProject
//
//  Created by Yusuf Özgül on 24.11.2018.
//  Copyright © 2018 Yusuf Özgül. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var fruitsCollectionView: UICollectionView!
    
//    Seçilen meyve bilgileri
    var selectedFruitsImage = ""
    var selectedFruitsName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
//    segue sırasında ilgili viewcontroller'a bilgi akışını sağladık, içindeki if ile doğru viewcontroller'a gittik
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetails"
        {
            let details = segue.destination as! detailsVC
            details.selectedFruitsImage = selectedFruitsImage
            details.selectedFruitsName = selectedFruitsName
        }
    }
}
//Kodun temiz görünmesi için collectionview kodlarını extension içine aldık, bunun class içinde tanımlamayla hiçbir farkı yok.
extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource
{
//    Bu fonksiyon ile bir index yani collectionview cell'i seçildiğinde yapılacak işlemler
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let fruits = setData.data.dataGet()[indexPath.row]
        selectedFruitsName = fruits.fruitName
        selectedFruitsImage = fruits.fruitImage
        performSegue(withIdentifier: "toDetails", sender: nil)
    }
//    Collectionview için kaç adet cell bulunacağını belirler.
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return setData.data.dataGet().count
    }
    
//    CollectionView Cell'lerini yerleştirir. Cell'deki ögelerle ilgili işlemler buradan yapabilirsiniz.
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as? fruitsCell
        {
            let fruits = setData.data.dataGet()[indexPath.row]
            cell.updateCell(fruit: fruits)
            
            return cell
        }
        else
        {
            return fruitsCell()
        }
    }
}

