//
//  fruits.swift
//  CollectionViewProject
//
//  Created by Yusuf Özgül on 24.11.2018.
//  Copyright © 2018 Yusuf Özgül. All rights reserved.
//

import Foundation

//      Struct içinde meyvelerimizi tutmak için isim ve fotoğraf değişkenlerini ekledik, Private olmasının sebebi ise sadece istediğimiz yerden değişim yapılabilsin ve kodda yanlıştıkla değiştirme yapmamamız için. init fonksiyonu ise struct'a veri eklemek için.

struct fruits {
    private (set) public var fruitImage :String
    private (set) public var fruitName :String
    
    init(image :String, name :String)
    {
        self.fruitImage = image
        self.fruitName = name
    }
}


//      Bu sınıf meyvelerimizi girip kolayca yönetebilmek için.

class setData
{
    static let data = setData()
    
    private let fruit = [
        fruits(image: "ananas", name: "Ananas"),
        fruits(image: "armut", name: "Armut"),
        fruits(image: "avakado", name: "Avakado"),
        fruits(image: "cilek", name: "Çilek"),
        fruits(image: "domates", name: "Domates"),
        fruits(image: "elma", name: "Elma"),
        fruits(image: "erik", name: "Erik"),
        fruits(image: "karpuz", name: "Karpuz"),
        fruits(image: "kivi", name: "Kivi"),
        fruits(image: "liimon", name: "Limon"),
        fruits(image: "nar", name: "Nar"),
        fruits(image: "seftali", name: "Şeftali")
    ]
    
    func dataGet() -> [fruits]
    {
        return fruit
    }
}
