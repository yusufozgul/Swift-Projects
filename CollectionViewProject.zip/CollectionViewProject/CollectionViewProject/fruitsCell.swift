//
//  fruitsCell.swift
//  CollectionViewProject
//
//  Created by Yusuf Özgül on 24.11.2018.
//  Copyright © 2018 Yusuf Özgül. All rights reserved.
//


import UIKit

class fruitsCell: UICollectionViewCell {
    
//    Bu kısım cell'imiz içinde bulunan ögeleri tutup, cell'imizi güncellemek için gereken fonksiyonu barındırıyor.
    
    @IBOutlet weak var fruitsImage: UIImageView!
    @IBOutlet weak var fruitsNameLabel: UILabel!
    
    func updateCell(fruit: fruits)
    {
        fruitsImage.image = UIImage(named: fruit.fruitImage)
        fruitsNameLabel.text = fruit.fruitName
    }
}
