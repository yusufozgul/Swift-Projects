//
//  detailsVC.swift
//  CollectionViewProject
//
//  Created by Yusuf Özgül on 24.11.2018.
//  Copyright © 2018 Yusuf Özgül. All rights reserved.
//

import UIKit

class detailsVC: UIViewController {
    
    
//    Meyve bilgilerimizi tutup ayrıntılı göstermek için.
    
    @IBOutlet weak var fruitsImage: UIImageView!
    @IBOutlet weak var fruitsName: UILabel!
    
    var selectedFruitsImage = ""
    var selectedFruitsName = ""
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        fruitsName.text = selectedFruitsName
        fruitsImage.image = UIImage(named: selectedFruitsImage)
    }
}
