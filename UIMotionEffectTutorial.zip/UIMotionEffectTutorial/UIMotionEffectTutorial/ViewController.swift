//
//  ViewController.swift
//  UIMotionEffectTutorial
//
//  Created by Yusuf Özgül on 11.05.2019.
//  Copyright © 2019 Yusuf Özgül. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var redView: UIView!
    @IBOutlet weak var blueView: UIView!
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        setUpRedViewTransforms()
        setUpAddButton()
    }

    func setUpAddButton()
    {
        blueView.layer.cornerRadius = 30 // Köşelerin yuvarlanması
        
        let horizontalEffect = UIInterpolatingMotionEffect( // Yatay efekt ayarları
            keyPath: "center.x",
            type: .tiltAlongHorizontalAxis)
        horizontalEffect.minimumRelativeValue = 50
        horizontalEffect.maximumRelativeValue = -50
        
        let verticalEffect = UIInterpolatingMotionEffect( // Dikey efekt ayarları
            keyPath: "center.y",
            type: .tiltAlongVerticalAxis)
        verticalEffect.minimumRelativeValue = 50
        verticalEffect.maximumRelativeValue = -50
        
        let effectGroup = UIMotionEffectGroup() // Efektimizi grup haline hetirip ekliyoruzç
        effectGroup.motionEffects = [horizontalEffect, verticalEffect]
        
        blueView.addMotionEffect(effectGroup)
        
    }
    
    func setUpRedViewTransforms()
    {
        var identity = CATransform3DIdentity // Efekt açısı.
        identity.m34 = -1 / 200.0
        
        let minimumTransform = CATransform3DRotate(identity, (315 * .pi) / 180.0, 1.0, 0.0, 0.0) // Min hareket
        let maximumTransform = CATransform3DRotate(identity, (45 * .pi) / 180.0, 1.0, 0.0, 0.0) // Max hareket
        
        redView.layer.transform = identity
        
        let effect = UIInterpolatingMotionEffect( // Efekt ayarımız
            keyPath: "layer.transform",
            type: .tiltAlongVerticalAxis)
        effect.minimumRelativeValue = minimumTransform
        effect.maximumRelativeValue = maximumTransform
        
        redView.addMotionEffect(effect)
    }

}

