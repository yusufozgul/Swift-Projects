//
//  Slide.swift
//  scrollProject
//
//  Created by Yusuf Özgül on 8.11.2018.
//  Copyright © 2018 Yusuf Özgül. All rights reserved.
//

import UIKit

class Slide: UIView {

   
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descText: UITextView!
    
}
